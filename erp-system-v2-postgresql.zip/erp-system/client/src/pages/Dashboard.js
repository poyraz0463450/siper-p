import React, { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import {
  FiPackage, FiLayers, FiTrendingUp, FiTrendingDown, FiFileText,
  FiAlertCircle, FiAlertTriangle, FiCheckCircle, FiClock,
  FiActivity, FiRefreshCw, FiChevronRight, FiShield,
  FiBox, FiTarget, FiZap, FiBell
} from 'react-icons/fi';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend,
  AreaChart, Area,
  LineChart, Line
} from 'recharts';
import { useAuth } from '../context/AuthContext';
import './Dashboard.css';

// ─── Durum renkleri ───
const STATUS_CONFIG = {
  draft: { label: 'Taslak', color: '#78909C', bg: '#ECEFF1' },
  pending: { label: 'Beklemede', color: '#F57F17', bg: '#FFF8E1' },
  pending_approval: { label: 'Onay Bekliyor', color: '#E65100', bg: '#FFF3E0' },
  approved: { label: 'Onaylı', color: '#1565C0', bg: '#E3F2FD' },
  in_production: { label: 'Üretimde', color: '#2E7D32', bg: '#E8F5E9' },
  in_progress: { label: 'Devam Ediyor', color: '#2E7D32', bg: '#E8F5E9' },
  quality_check: { label: 'Kalite Kontrol', color: '#6A1B9A', bg: '#F3E5F5' },
  completed: { label: 'Tamamlandı', color: '#1B5E20', bg: '#C8E6C9' },
  cancelled: { label: 'İptal', color: '#B71C1C', bg: '#FFCDD2' },
};

const PRIORITY_CONFIG = {
  low: { label: 'Düşük', color: '#78909C' },
  normal: { label: 'Normal', color: '#1565C0' },
  high: { label: 'Yüksek', color: '#E65100' },
  urgent: { label: 'Acil', color: '#B71C1C' },
};

const PIE_COLORS = ['#1B2A4A', '#C8102E', '#2E7D32', '#E65100', '#1565C0', '#6A1B9A', '#78909C'];

const Dashboard = () => {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [stats, setStats] = useState({
    models: 0, parts: 0, lowStock: 0, pendingOrders: 0,
    totalOrders: 0, completedOrders: 0, inProductionOrders: 0, criticalParts: 0,
  });
  const [lowStockItems, setLowStockItems] = useState([]);
  const [recentOrders, setRecentOrders] = useState([]);
  const [ordersByStatus, setOrdersByStatus] = useState([]);
  const [inventoryData, setInventoryData] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [currentTime, setCurrentTime] = useState(new Date());

  // Saat güncellemesi
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 60000);
    return () => clearInterval(timer);
  }, []);

  // Yeni aggregated endpoint (tek çağrı) + eski endpoint fallback
  const fetchAllData = useCallback(async (isRefresh = false) => {
    if (isRefresh) setRefreshing(true);
    try {
      // Önce yeni endpoint'i dene
      let usedNewEndpoint = false;
      try {
        const { data } = await axios.get('/api/dashboard/stats');
        usedNewEndpoint = true;

        const k = data.kpis;
        setStats({
          models: k.models,
          parts: k.parts,
          lowStock: k.low_stock,
          pendingOrders: k.pending_orders,
          totalOrders: k.total_orders,
          completedOrders: k.completed_orders,
          inProductionOrders: k.in_production_orders,
          criticalParts: k.critical_parts,
        });

        setLowStockItems(data.lists.low_stock_items || []);
        setRecentOrders(data.lists.recent_orders || []);
        setNotifications(k.unread_notifications > 0 ? [{ count: k.unread_notifications }] : []);

        // Pie chart
        const statusLabels = data.charts.orders_by_status.map(s => {
          const cfg = STATUS_CONFIG[s.status] || { label: s.status };
          return { name: cfg.label, value: s.count };
        });
        setOrdersByStatus(statusLabels);

        // Bar chart
        setInventoryData(
          (data.charts.inventory_levels || []).map(i => ({
            name: i.code || i.name?.substring(0, 12),
            mevcut: i.current,
            minimum: i.minimum,
          }))
        );
      } catch (e) {
        // Yeni endpoint yoksa eski yönteme düş
      }

      // Fallback: eski bireysel endpoint'ler
      if (!usedNewEndpoint) {
        const [modelsRes, partsRes, lowStockRes, ordersRes, inventoryRes] = await Promise.all([
          axios.get('/api/models'),
          axios.get('/api/parts'),
          axios.get('/api/inventory/alerts/low-stock').catch(() => ({ data: [] })),
          axios.get('/api/production-orders'),
          axios.get('/api/inventory'),
        ]);

        const orders = ordersRes.data;
        const pending = orders.filter(o => ['pending', 'pending_approval', 'approved'].includes(o.status));
        const inProd = orders.filter(o => ['in_production', 'in_progress'].includes(o.status));
        const completed = orders.filter(o => o.status === 'completed');
        const criticalParts = partsRes.data.filter(p => p.is_critical);

        setStats({
          models: modelsRes.data.length,
          parts: partsRes.data.length,
          lowStock: lowStockRes.data.length,
          pendingOrders: pending.length,
          totalOrders: orders.length,
          completedOrders: completed.length,
          inProductionOrders: inProd.length,
          criticalParts: criticalParts.length,
        });

        setLowStockItems(lowStockRes.data.slice(0, 8));
        setRecentOrders(orders.slice(0, 6));
        setNotifications([]);

        const statusCounts = {};
        orders.forEach(o => {
          const cfg = STATUS_CONFIG[o.status] || { label: o.status };
          statusCounts[cfg.label] = (statusCounts[cfg.label] || 0) + 1;
        });
        setOrdersByStatus(Object.entries(statusCounts).map(([name, value]) => ({ name, value })));

        const inv = inventoryRes.data
          .filter(i => i.quantity > 0 || i.min_quantity > 0)
          .sort((a, b) => {
            const ratioA = a.min_quantity > 0 ? a.quantity / a.min_quantity : 999;
            const ratioB = b.min_quantity > 0 ? b.quantity / b.min_quantity : 999;
            return ratioA - ratioB;
          })
          .slice(0, 10)
          .map(i => ({
            name: i.part_code || i.part_name?.substring(0, 12),
            mevcut: i.quantity,
            minimum: i.min_quantity || 0,
          }));
        setInventoryData(inv);
      }
    } catch (error) {
      console.error('Dashboard veri hatası:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    fetchAllData();
  }, [fetchAllData]);

  const handleRefresh = () => fetchAllData(true);

  // Selamlama
  const getGreeting = () => {
    const hour = currentTime.getHours();
    if (hour < 12) return 'Günaydın';
    if (hour < 18) return 'İyi günler';
    return 'İyi akşamlar';
  };

  const formatDate = (dateStr) => {
    if (!dateStr) return '-';
    const d = new Date(dateStr);
    return d.toLocaleDateString('tr-TR', { day: '2-digit', month: 'short', year: 'numeric' });
  };

  const formatTime = (dateStr) => {
    if (!dateStr) return '';
    const d = new Date(dateStr);
    return d.toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
  };

  // Üretim performans verileri (simüle - gerçek veride API'den gelecek)
  const monthlyData = (() => {
    const months = ['Oca', 'Şub', 'Mar', 'Nis', 'May', 'Haz', 'Tem', 'Ağu', 'Eyl', 'Eki', 'Kas', 'Ara'];
    const currentMonth = currentTime.getMonth();
    return months.slice(0, currentMonth + 1).map((m, i) => ({
      name: m,
      uretim: Math.floor(stats.completedOrders / (currentMonth + 1) * (0.7 + Math.random() * 0.6) * (i + 1) / (currentMonth + 1) * 2),
      hedef: Math.ceil(stats.totalOrders / 12),
    }));
  })();

  if (loading) {
    return (
      <div className="dashboard-loading">
        <div className="loading-spinner" />
        <p>Kontrol paneli yükleniyor...</p>
      </div>
    );
  }

  return (
    <div className="dashboard-v2">
      {/* ═══ HEADER ═══ */}
      <div className="dashboard-header">
        <div className="header-left">
          <h1>
            <FiShield className="header-icon" />
            Kontrol Paneli
          </h1>
          <p className="header-greeting">
            {getGreeting()}, <strong>{user?.full_name || user?.username}</strong>
            <span className="header-date">
              {currentTime.toLocaleDateString('tr-TR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
            </span>
          </p>
        </div>
        <div className="header-right">
          {notifications.length > 0 && (
            <div className="header-notif-badge">
              <FiBell />
              <span className="notif-count">{notifications.length}</span>
            </div>
          )}
          <button className={`refresh-btn ${refreshing ? 'spinning' : ''}`} onClick={handleRefresh} title="Yenile">
            <FiRefreshCw />
          </button>
        </div>
      </div>

      {/* ═══ KPI CARDS ═══ */}
      <div className="kpi-grid">
        <Link to="/models" className="kpi-card">
          <div className="kpi-icon kpi-blue"><FiLayers /></div>
          <div className="kpi-content">
            <span className="kpi-value">{stats.models}</span>
            <span className="kpi-label">Silah Modeli</span>
          </div>
          <FiChevronRight className="kpi-arrow" />
        </Link>

        <Link to="/parts" className="kpi-card">
          <div className="kpi-icon kpi-steel"><FiPackage /></div>
          <div className="kpi-content">
            <span className="kpi-value">{stats.parts}</span>
            <span className="kpi-label">Toplam Parça</span>
          </div>
          <FiChevronRight className="kpi-arrow" />
        </Link>

        <Link to="/production-orders" className="kpi-card">
          <div className="kpi-icon kpi-green"><FiActivity /></div>
          <div className="kpi-content">
            <span className="kpi-value">{stats.inProductionOrders}</span>
            <span className="kpi-label">Üretimde</span>
          </div>
          <FiChevronRight className="kpi-arrow" />
        </Link>

        <Link to="/production-orders" className="kpi-card">
          <div className="kpi-icon kpi-amber"><FiClock /></div>
          <div className="kpi-content">
            <span className="kpi-value">{stats.pendingOrders}</span>
            <span className="kpi-label">Bekleyen Emir</span>
          </div>
          <FiChevronRight className="kpi-arrow" />
        </Link>

        <Link to="/inventory" className="kpi-card kpi-alert">
          <div className="kpi-icon kpi-red"><FiAlertTriangle /></div>
          <div className="kpi-content">
            <span className="kpi-value">{stats.lowStock}</span>
            <span className="kpi-label">Düşük Stok</span>
          </div>
          <FiChevronRight className="kpi-arrow" />
        </Link>

        <Link to="/production-orders" className="kpi-card">
          <div className="kpi-icon kpi-navy"><FiCheckCircle /></div>
          <div className="kpi-content">
            <span className="kpi-value">{stats.completedOrders}</span>
            <span className="kpi-label">Tamamlanan</span>
          </div>
          <FiChevronRight className="kpi-arrow" />
        </Link>
      </div>

      {/* ═══ CHARTS ROW ═══ */}
      <div className="charts-row">
        {/* Üretim Trendi */}
        <div className="chart-card chart-wide">
          <div className="chart-header">
            <h3><FiTrendingUp /> Üretim Trendi</h3>
            <span className="chart-subtitle">{currentTime.getFullYear()} yılı aylık</span>
          </div>
          <div className="chart-body">
            <ResponsiveContainer width="100%" height={260}>
              <AreaChart data={monthlyData}>
                <defs>
                  <linearGradient id="gradUretim" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#1B2A4A" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#1B2A4A" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#E8ECF2" />
                <XAxis dataKey="name" tick={{ fontSize: 12, fill: '#607D8B' }} />
                <YAxis tick={{ fontSize: 12, fill: '#607D8B' }} />
                <Tooltip
                  contentStyle={{ background: '#fff', border: '1px solid #E0E0E0', borderRadius: 8, fontSize: 13 }}
                />
                <Area type="monotone" dataKey="uretim" name="Üretim" stroke="#1B2A4A" fill="url(#gradUretim)" strokeWidth={2.5} />
                <Line type="monotone" dataKey="hedef" name="Hedef" stroke="#C8102E" strokeDasharray="5 5" strokeWidth={2} dot={false} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Emirler Durum Dağılımı */}
        <div className="chart-card">
          <div className="chart-header">
            <h3><FiTarget /> Emir Dağılımı</h3>
            <span className="chart-subtitle">Toplam: {stats.totalOrders}</span>
          </div>
          <div className="chart-body">
            {ordersByStatus.length > 0 ? (
              <ResponsiveContainer width="100%" height={260}>
                <PieChart>
                  <Pie
                    data={ordersByStatus}
                    cx="50%" cy="50%"
                    innerRadius={55}
                    outerRadius={90}
                    paddingAngle={3}
                    dataKey="value"
                    label={({ name, value }) => `${name}: ${value}`}
                    labelLine={{ stroke: '#90A4AE', strokeWidth: 1 }}
                  >
                    {ordersByStatus.map((entry, idx) => (
                      <Cell key={idx} fill={PIE_COLORS[idx % PIE_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="chart-empty">
                <FiFileText />
                <p>Henüz üretim emri yok</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* ═══ STOK GRAFİĞİ ═══ */}
      {inventoryData.length > 0 && (
        <div className="chart-card chart-full">
          <div className="chart-header">
            <h3><FiBox /> Kritik Stok Durumu</h3>
            <span className="chart-subtitle">En düşük stok oranına sahip parçalar</span>
          </div>
          <div className="chart-body">
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={inventoryData} barGap={2}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E8ECF2" />
                <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#607D8B' }} angle={-20} textAnchor="end" height={50} />
                <YAxis tick={{ fontSize: 12, fill: '#607D8B' }} />
                <Tooltip contentStyle={{ background: '#fff', border: '1px solid #E0E0E0', borderRadius: 8, fontSize: 13 }} />
                <Legend wrapperStyle={{ fontSize: 12 }} />
                <Bar dataKey="mevcut" name="Mevcut Stok" fill="#1B2A4A" radius={[4, 4, 0, 0]} />
                <Bar dataKey="minimum" name="Min. Stok" fill="#C8102E" radius={[4, 4, 0, 0]} opacity={0.7} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {/* ═══ BOTTOM ROW ═══ */}
      <div className="bottom-row">
        {/* Düşük Stok Uyarıları */}
        <div className="panel-card">
          <div className="panel-header">
            <h3><FiAlertCircle className="icon-warning" /> Düşük Stok Uyarıları</h3>
            <Link to="/inventory" className="panel-link">Tümünü Gör <FiChevronRight /></Link>
          </div>
          <div className="panel-body">
            {lowStockItems.length === 0 ? (
              <div className="panel-empty">
                <FiCheckCircle className="icon-success" />
                <p>Tüm stok seviyeleri normal</p>
              </div>
            ) : (
              <div className="alert-list">
                {lowStockItems.map((item, idx) => (
                  <div key={idx} className={`alert-row ${item.is_critical ? 'critical' : ''}`}>
                    <div className="alert-info">
                      <span className="alert-name">{item.part_name}</span>
                      <span className="alert-code">{item.part_code}</span>
                    </div>
                    <div className="alert-stock">
                      <div className="stock-bar">
                        <div
                          className="stock-fill"
                          style={{
                            width: `${Math.min(100, item.min_quantity > 0 ? (item.quantity / item.min_quantity) * 100 : 0)}%`,
                            background: item.quantity === 0 ? '#B71C1C' : item.quantity < item.min_quantity / 2 ? '#E65100' : '#F57F17',
                          }}
                        />
                      </div>
                      <span className="stock-numbers">
                        <strong>{item.quantity}</strong> / {item.min_quantity}
                      </span>
                    </div>
                    {item.is_critical && <span className="critical-badge">KRİTİK</span>}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Son Üretim Emirleri */}
        <div className="panel-card">
          <div className="panel-header">
            <h3><FiFileText /> Son Üretim Emirleri</h3>
            <Link to="/production-orders" className="panel-link">Tümünü Gör <FiChevronRight /></Link>
          </div>
          <div className="panel-body">
            {recentOrders.length === 0 ? (
              <div className="panel-empty">
                <FiFileText />
                <p>Henüz üretim emri yok</p>
              </div>
            ) : (
              <div className="orders-list">
                {recentOrders.map((order, idx) => {
                  const statusCfg = STATUS_CONFIG[order.status] || { label: order.status, color: '#78909C', bg: '#ECEFF1' };
                  const priorityCfg = PRIORITY_CONFIG[order.priority] || { label: order.priority, color: '#78909C' };
                  return (
                    <div key={idx} className="order-row">
                      <div className="order-main">
                        <div className="order-number">{order.order_number}</div>
                        <div className="order-model">{order.model_name || 'Model'}</div>
                      </div>
                      <div className="order-meta">
                        <span className="order-qty">{order.quantity} adet</span>
                        <span className="order-date">{formatDate(order.created_at)}</span>
                      </div>
                      <div className="order-badges">
                        <span className="status-badge" style={{ color: statusCfg.color, background: statusCfg.bg }}>
                          {statusCfg.label}
                        </span>
                        {order.priority !== 'normal' && (
                          <span className="priority-dot" style={{ background: priorityCfg.color }} title={priorityCfg.label} />
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* ═══ QUICK STATS FOOTER ═══ */}
      <div className="quick-stats">
        <div className="quick-stat">
          <FiZap className="qs-icon" />
          <div className="qs-content">
            <span className="qs-value">{stats.totalOrders > 0 ? Math.round(stats.completedOrders / stats.totalOrders * 100) : 0}%</span>
            <span className="qs-label">Tamamlanma Oranı</span>
          </div>
        </div>
        <div className="quick-stat">
          <FiTarget className="qs-icon" />
          <div className="qs-content">
            <span className="qs-value">{stats.criticalParts}</span>
            <span className="qs-label">Emniyet Kritik Parça</span>
          </div>
        </div>
        <div className="quick-stat">
          <FiBox className="qs-icon" />
          <div className="qs-content">
            <span className="qs-value">{stats.parts > 0 ? stats.parts - stats.lowStock : 0}</span>
            <span className="qs-label">Stokta Yeterli</span>
          </div>
        </div>
        <div className="quick-stat">
          <FiTrendingUp className="qs-icon" />
          <div className="qs-content">
            <span className="qs-value">{stats.inProductionOrders + stats.completedOrders}</span>
            <span className="qs-label">Aktif Üretim</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
